package ejercicio4;

public interface Prestable {
	//interfaz que implementa estos métodos
	void presta();
	void devuelve();
	boolean estaPrestado();
}
