package com.ellago;

public class Ampliacion {

	public static void Ejercicio1() {
		
		int[]num = new int[12];
		num[0]=39;
		num[1]=-2;
		num[4]=0;
		num[6]=14;
		num[8]=5;
		num[9]=120;
		
		for (int i = 0; i < num.length; i++) {
			System.out.print(i + ": "+num[i]+"   ");
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ejercicio1();
	}

}
