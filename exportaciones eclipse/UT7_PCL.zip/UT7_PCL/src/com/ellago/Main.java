package com.ellago;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int[] arrayInt = Array.crearArrayInt(10);       
		int[] arrayInt2 = Array.crearArrayInt(10);
		String[] mcdonalds = Array.crearArrayString(10);
		Persona[] arrayPersona = Array.crearArrayPersona(10);
		int[][] matrizInt = Array.crearMatrizInt(3,3);
		
		int x = Frecursivas.potencia(5,4);
		System.out.println(x);
		
		System.out.println(Frecursivas.sumarDig(523));
		
		/*System.out.println(Frecursivas.factorial(5));
		for (int i = 0; i < 10; i++) {
			System.out.println(Frecursivas.fibonacci(i));
		}*/


		/*Array.mostrarArrayString(Array.crearArrayString(5));*/
		
		/*Array.mostrarArrayInt(arrayInt);
		System.out.println(Array.buscarArrayInt(arrayInt,8));
		
		/*Array.mostrarArrayString(arrayString);
		System.out.println(Array.buscarArrayString(arrayString,"Dato6"));*/
		
		/*Array.mostrarArrayInt(arrayInt);
		System.out.println(Array.localizaPosInt(arrayInt, 5));
		
		Array.mostrarArrayString(arrayString);
		System.out.println(Array.localizaPosString(arrayString, "Dato2"));*/
		
		/*Array.mostrarArrayInt(arrayInt);
		System.out.println(Array.vecesIntArray(arrayInt,2));
		
		Array.mostrarArrayString(arrayString);
		System.out.println(Array.vecesStringArray(arrayString,"Dato1"));*/
		
		/*for (int i = 0; i < arrayString.length; i++) {
			
			System.out.println(Array.unirArraysInt(arrayInt, arrayInt2)[i]);
			
		}*/
		
		/*
		Array.mostrarArrayInt(arrayInt);
		System.out.println(Array.sustituirIntArray(arrayInt, 2, 2000));
		Array.mostrarArrayInt(arrayInt);
		
		Array.mostrarArrayString(arrayString);
		System.out.println(Array.sustituirStringArray(arrayString, "Dato5", "Caraculo"));
		Array.mostrarArrayString(arrayString);*/
		
		/*
		Array.mostrarArrayInt(arrayInt);
		Array.ordenarIntArray(arrayInt);
		*/
		/*
		Array.mostrarArrayString(arrayString);
		Array.ordenarStringArray(arrayString);
		*/
		
		/*
		Array.mostrarArrayInt(arrayInt);
		Array.ordenarIntArray(arrayInt);
		System.out.println("\n"+Array.buscarInt(arrayInt, 3));
		*/
		
		/*
		Array.mostrarArrayString(arrayString);
		Array.ordenarStringArray(arrayString);
		System.out.println("\n"+Array.buscarString(arrayString, "Dato2"));
		*/
		/*
		Array.mostrarArrayInt(arrayInt);
		Arrays.sort(arrayInt);
		Array.mostrarArrayInt(arrayInt);
		
		Array.mostrarArrayString(arrayString);
		Arrays.sort(arrayString);
		Array.mostrarArrayString(arrayString);
		*/
		
//		Array.mostrarArrayPersona(arrayPersona);
//		Array.ordenarArrayPersona2(arrayPersona);
		
		
		
	}

}
