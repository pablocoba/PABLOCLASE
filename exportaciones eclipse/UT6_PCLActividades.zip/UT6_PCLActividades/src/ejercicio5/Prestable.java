package ejercicio5;

public interface Prestable {
	void presta();
	void devuelve();
	boolean estaPrestado();
}
