package ejercicio2;

public class CompraVenta extends Zona {

	public CompraVenta(int n) {
		super(n);
	}
		

}
