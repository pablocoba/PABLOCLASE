package ejercicio2;

public class Principal extends Zona{

	
	public Principal(int n) {
		super(n);
	}
	
}
